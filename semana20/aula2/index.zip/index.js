"use strict";
exports.myFunc = async (event) => {
    return "Olá mundo, sou uma mensagem da AWS";
};
